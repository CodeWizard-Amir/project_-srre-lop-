const numHarmonics = 180;
const xValues = [];
const yValues = [];
for (let x = 0; x <= 30; x += 0.01) {
  let sum = 0;
  for (let k = 1; k <= numHarmonics; k++) {
    sum += -(1/2*x*Math.PI * Math.sin(2 * k * Math.PI * x));
  }
  const y = 0.5 + sum;
  xValues.push(x);
  yValues.push(y);
}
// تا اینجا مقدار تابع رو حساب کردیم با توجه به فرمول 0.5 به علاوه سیگما یک سینوسی بود
// در نهایت درون یک ارایه پوش کردم تا مقادیر یه یه یک باهم ست شوند برای نمایش در نمودار
// =======================================================================================================

// در اینجا از یک کتابخانه جاواسکرپتی به نام
// chart.js
// استفاده کردم که در وبسایت ها بسیار مورد استفاده قرار میگیرد
// به این صورت کار میکند که مقادیر را به صورت یک ارایه برای محور های x و y
// همچنین یکسری تنظیمات داره برای مثال رنگ بوردر ها و... هایلایت کردن مقادیر زیر نمودار و...
// که در این مثال هم بنده استفاده کردم
const ctx = document.getElementById("fourierChart").getContext("2d");
const fourierChart = new Chart(ctx, {
  type: "line",
  data: {
    labels: xValues,
    datasets: [
      {
        label: "سری فوریه",
        data: yValues,
        borderColor: "rgba(75, 192, 192, 1)",
        borderWidth: 3,
        fill: false,
      },
    ],
  },
  options: {
    scales: {
      y: {
        beginAtZero: true,
        min: -numHarmonics,
        max: numHarmonics,
      },
    },
  },
});
// امیرسجاد نوی
